// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getStorage } from 'firebase/storage';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getDatabase } from 'firebase/database';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB3-Xn9-qIrJMd5_P7wlsFfHXRPUg9qlVQ",
  authDomain: "md18309-f3801.firebaseapp.com",
  projectId: "md18309-f3801",
  storageBucket: "md18309-f3801.appspot.com",
  messagingSenderId: "711245614988",
  appId: "1:711245614988:web:40d61962ed5c53f17b90a9",
  measurementId: "G-J97QPH6672"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const FIREBASE_APP = initializeApp(firebaseConfig);
export const FIREBASE_AUTH = getAuth(FIREBASE_APP);
export const FIRESTORE_DB = getFirestore(FIREBASE_APP);
export const STORAGE = getStorage(FIREBASE_APP);
export const DATABASE = getDatabase(FIREBASE_APP);