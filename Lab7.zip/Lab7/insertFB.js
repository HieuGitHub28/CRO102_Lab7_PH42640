import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import { FIRESTORE_DB } from './firebaseConfig';
// Assuming FIREBASE_APP has already been initialized

const App71 = () => {
  const [text, setText] = useState('');

  const handleAddData = async () => {
    try {
      const docRef = await addDoc(collection(FIRESTORE_DB, 'SinhViens'), {
        text: text
      });
      console.log('Tai lieu duoc ghi voi ID: ', docRef.id);
      setText('');
    } catch (error) {
      console.error('Loi ghi du lieu: ', error);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Enter text"
        value={text}
        onChangeText={setText}
      />
      <Button
        title="Add Data"
        onPress={handleAddData}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
});

export default App71;